n1=int(input("digite um número inteiro: "))
nx2=n1**2
nx3=n1**3
print("o número digitado possui o valor do seu quadrado em",nx2,"e seu cubo vale",nx3)