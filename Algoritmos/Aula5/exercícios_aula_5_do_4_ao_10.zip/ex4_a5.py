n1=float(input("digite o valor da base: "))
n2=float(input("digite o valor da altura: "))
print("a área do retangulo é ", n1*n2)