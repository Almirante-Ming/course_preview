import math
n1=float(input("digite o valor do raio: "))
print("a área do círculo é", (n1*math.pi)**2)