n1=int(input("digite um número: "))
n2=int(input("digite outro número: "))
n3=int(input("digite mais um número: "))

print("o resultado é", n1+n2+n3)