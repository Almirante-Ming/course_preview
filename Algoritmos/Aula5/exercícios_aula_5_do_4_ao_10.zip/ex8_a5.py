real=float(input("digite a quantia a ser convertida: "))
euro=5.38
cotacao=real/euro
print("o valor da conversão (BRL -> EUR) é: ",cotacao)