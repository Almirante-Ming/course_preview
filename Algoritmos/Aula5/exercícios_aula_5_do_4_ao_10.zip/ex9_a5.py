tempF=float(input("digite a temperatura a ser convertida: "))
tempC=((tempF-32)*5)/9
print("a temperatura em graus Celsius é: ",tempC)