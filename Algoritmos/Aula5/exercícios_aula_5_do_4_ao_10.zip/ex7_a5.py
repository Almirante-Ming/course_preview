n1=int(input("digite um número inteiro: "))
nA1=n1-1
nN1=n1+1
print("de acordo com o número digitado, o seu antecessor vale ",nA1,"e seu sucessor vale ",nN1)